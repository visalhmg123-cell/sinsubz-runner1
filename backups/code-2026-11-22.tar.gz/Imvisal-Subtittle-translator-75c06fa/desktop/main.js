const { app, BrowserWindow, ipcMain, shell, Menu, Notification, Tray, nativeImage, dialog } = require("electron");
const path = require("path");
const fs = require("fs");
const { runExport, probeSubs } = require("./export-video");

// The desktop app has no server of its own: /api/... calls go to the deployed site.
const API_ORIGIN = "https://subtittle-translator.vercel.app";

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
    app.exit(0);
}

// "Start with Windows" launches with --hidden: stay in the tray, do not pop the window up
const START_HIDDEN = process.argv.includes("--hidden");

let win;
let tray = null;
let quitting = false;
let trayHintShown = false;

function createWindow() {
    win = new BrowserWindow({
        width: 1280,
        height: 820,
        minWidth: 900,
        minHeight: 600,
        backgroundColor: "#07080d",
        title: "SinSubz",
        icon: path.join(__dirname, "app", "logo.png"),
        autoHideMenuBar: true,
        show: !START_HIDDEN,
        webPreferences: {
            preload: path.join(__dirname, "preload.js"),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
            backgroundThrottling: false   // keep release checks running while hidden in the tray
        }
    });

    Menu.setApplicationMenu(null);
    win.loadFile(path.join(__dirname, "app", "index.html"));

    // Closing the window keeps the app in the system tray so new-release
    // notifications keep arriving. Use the tray menu -> Quit to exit.
    win.on("close", (event) => {
        if (quitting) return;
        event.preventDefault();
        win.hide();
        if (!trayHintShown) {
            trayHintShown = true;
            toast(
                "SinSubz is still running",
                "It stays in the system tray to tell you about new movies and Sinhala subtitles. Right-click the tray icon to quit.",
                true
            );
        }
    });

    // external links open in the normal browser
    // the app never needs camera / mic / location etc.: deny every permission prompt
    win.webContents.session.setPermissionRequestHandler((_wc, _permission, callback) => callback(false));

    win.webContents.setWindowOpenHandler(({ url }) => {
        if (/^https?:\/\//i.test(url)) shell.openExternal(url);
        return { action: "deny" };
    });
    win.webContents.on("will-navigate", (event, url) => {
        if (!url.startsWith("file://")) {
            event.preventDefault();
            if (/^https?:\/\//i.test(url)) shell.openExternal(url);
        }
    });
}

// Network calls run here (not in the page) so there are no CORS problems.
// Only our own bundled page (file://) may talk to the main process.
function fromOurPage(event) {
    try {
        const u = (event.senderFrame && event.senderFrame.url) || event.sender.getURL();
        return typeof u === "string" && u.startsWith("file://");
    } catch (e) {
        return false;
    }
}

ipcMain.handle("api-fetch", async (event, url, init) => {
    if (!fromOurPage(event)) throw new Error("Blocked request");
    const allowed =
        typeof url === "string" &&
        (url.startsWith(API_ORIGIN + "/api/") || url.startsWith(API_ORIGIN + "/version.json"));
    if (!allowed) {
        throw new Error("Blocked request");
    }
    const opts = {
        method: (init && init.method) || "GET",
        headers: Object.assign({}, (init && init.headers) || {}, {
            "User-Agent": "SinSubzDesktop/" + app.getVersion() + " Electron/" + process.versions.electron
        })
    };
    if (init && typeof init.body === "string") opts.body = init.body;

    opts.signal = AbortSignal.timeout(120000);
    const res = await fetch(url, opts);
    const buf = new Uint8Array(await res.arrayBuffer());
    if (buf.length > 25 * 1024 * 1024) throw new Error("Response too large");
    return {
        status: res.status,
        statusText: res.statusText,
        contentType: res.headers.get("content-type") || "",
        body: buf
    };
});

// Translation notifications + taskbar progress
function toast(title, body, silent, onClick) {
    if (!Notification.isSupported()) return;
    const n = new Notification({
        title,
        body,
        silent: !!silent,
        icon: path.join(__dirname, "app", "logo.png")
    });
    n.on("click", () => {
        if (onClick) {
            onClick();
            return;
        }
        if (win) {
            if (win.isMinimized()) win.restore();
            win.show();
            win.focus();
        }
    });
    n.show();
}

let startedToast = false;

// Save the translated / synced .srt into Downloads\SinSubz\
ipcMain.handle("save-file", async (event, text, filename) => {
    if (!fromOurPage(event)) throw new Error("Blocked request");
    if (typeof text !== "string" || typeof filename !== "string" || text.length > 10 * 1024 * 1024) {
        throw new Error("Invalid file");
    }

    const safeName =
        path.basename(filename).replace(/[<>:"/\\|?*\x00-\x1f]/g, "_").trim() || "subtitle.srt";

    const dir = path.join(app.getPath("downloads"), "SinSubz");
    fs.mkdirSync(dir, { recursive: true });

    const ext = path.extname(safeName);
    const base = path.basename(safeName, ext);
    let file = path.join(dir, safeName);
    for (let n = 1; fs.existsSync(file); n++) {
        file = path.join(dir, base + " (" + n + ")" + ext);
    }

    // UTF-8 BOM so Sinhala opens correctly in every player
    fs.writeFileSync(file, "\uFEFF" + text, "utf8");

    toast("Subtitle saved to Downloads", file, false, () => shell.showItemInFolder(file));
    return { path: file };
});

// ---- Play tab: pick a video, play it with a subtitle, save the subtitle next to it ----
// The video path stays here in the main process. The page only gets a file:// URL to play.
let currentVideo = null;
let currentVideoSubs = [];

ipcMain.handle("pick-video", async (event) => {
    if (!fromOurPage(event)) throw new Error("Blocked request");
    const r = await dialog.showOpenDialog(win, {
        title: "Choose a movie or episode",
        properties: ["openFile"],
        filters: [
            { name: "Video", extensions: ["mp4", "mkv", "webm", "m4v", "mov", "avi", "ogv"] },
            { name: "All files", extensions: ["*"] }
        ]
    });
    if (r.canceled || !r.filePaths.length) return null;
    currentVideo = r.filePaths[0];
    // does the video already carry its own subtitle track(s)? (the page shows a choice if so)
    currentVideoSubs = [];
    try { currentVideoSubs = await probeSubs(ffmpegBinary(), currentVideo); } catch (e) { /* ignore */ }
    return {
        name: path.basename(currentVideo),
        url: require("url").pathToFileURL(currentVideo).href,
        subs: currentVideoSubs
    };
});

ipcMain.handle("pick-subtitle", async (event) => {
    if (!fromOurPage(event)) throw new Error("Blocked request");
    const r = await dialog.showOpenDialog(win, {
        title: "Choose a subtitle (.srt)",
        properties: ["openFile"],
        filters: [{ name: "Subtitles", extensions: ["srt"] }]
    });
    if (r.canceled || !r.filePaths.length) return null;
    const file = r.filePaths[0];
    if (fs.statSync(file).size > 5 * 1024 * 1024) throw new Error("That file is too big for a subtitle.");
    return { name: path.basename(file), text: fs.readFileSync(file, "utf8") };
});

// "Movie.mkv" -> "Movie.si.srt" in the same folder (VLC, MPC-HC, PotPlayer... load it automatically)
ipcMain.handle("save-sub-next-to-video", async (event, text) => {
    if (!fromOurPage(event)) throw new Error("Blocked request");
    if (typeof text === "string" && text.length > 10 * 1024 * 1024) throw new Error("Subtitle is too big.");
    if (!currentVideo) throw new Error("Choose a video first.");
    if (typeof text !== "string" || !text.length) throw new Error("No subtitle to save.");
    const dir = path.dirname(currentVideo);
    const base = path.basename(currentVideo, path.extname(currentVideo));
    const file = path.join(dir, base + ".si.srt");
    fs.writeFileSync(file, "\uFEFF" + text, "utf8");
    return { path: file };
});

// ---- Merge tab: put the subtitle INTO the video file (ffmpeg) and save a new video ----
function ffmpegBinary() {
    // ffmpeg-static lives in app.asar.unpacked once the app is packaged
    return require("ffmpeg-static").replace("app.asar", "app.asar.unpacked");
}

let exportJob = null;

ipcMain.handle("export-video", async (event, opts) => {
    if (!fromOurPage(event)) throw new Error("Blocked request");
    if (!currentVideo) throw new Error("Choose a video first.");
    if (exportJob) throw new Error("A video is already being made.");
    if (!opts || typeof opts.srtText !== "string" || !opts.srtText.length) throw new Error("No subtitle to add.");
    if (opts.srtText.length > 10 * 1024 * 1024) throw new Error("Subtitle is too big.");

    const mode = opts.mode === "soft" ? "soft" : "burn";
    const vExt = path.extname(currentVideo).toLowerCase();
    const existingSubs = currentVideoSubs.length;
    const keepOriginal = mode === "soft" && !!opts.keepOriginal && existingSubs > 0;
    // mp4 can only hold text subtitles of one kind, so keeping the original tracks needs an .mkv
    const outExt = mode === "soft" && (vExt === ".mkv" || keepOriginal) ? ".mkv" : ".mp4";
    const base = path.basename(currentVideo, path.extname(currentVideo));

    const r = await dialog.showSaveDialog(win, {
        title: "Save the new video",
        defaultPath: path.join(path.dirname(currentVideo), base + ".Sinhala" + outExt),
        filters: outExt === ".mkv"
            ? [{ name: "MKV video", extensions: ["mkv"] }]
            : [{ name: "MP4 video", extensions: ["mp4"] }]
    });
    if (r.canceled || !r.filePath) return { cancelled: true };

    let out = r.filePath;
    if (path.extname(out).toLowerCase() !== outExt) out += outExt;
    if (path.resolve(out).toLowerCase() === path.resolve(currentVideo).toLowerCase()) {
        throw new Error("Save it under a different name. The original video is not touched.");
    }

    exportJob = runExport({
        ffmpegPath: ffmpegBinary(),
        video: currentVideo,
        srtText: opts.srtText,
        mode,
        keepOriginal,
        existingSubs,
        size: Math.min(120, Math.max(10, Number(opts.size) || 30)),
        out,
        onProgress: (p) => {
            if (win && !win.isDestroyed()) {
                win.webContents.send("export-progress", p);
                win.setProgressBar(p.percent / 100);
            }
        }
    });

    try {
        await exportJob.promise;
        if (win) win.setProgressBar(-1);
        toast("Video is ready \u2713", out, false, () => shell.showItemInFolder(out));
        return { path: out };
    } catch (e) {
        if (win) win.setProgressBar(-1);
        if (e && e.cancelled) return { cancelled: true };
        throw e;
    } finally {
        exportJob = null;
    }
});

ipcMain.on("export-cancel", () => { if (exportJob) exportJob.cancel(); });
ipcMain.on("show-in-folder", (event, p) => {
    if (fromOurPage(event) && typeof p === "string" && p.length < 1024 && fs.existsSync(p)) shell.showItemInFolder(p);
});

// Only https links may open in the browser (update downloads, announcement links)
ipcMain.on("open-external", (event, url) => {
    if (fromOurPage(event) && typeof url === "string" && url.length < 2048 && /^https:\/\/[^\s]+$/i.test(url)) {
        shell.openExternal(url);
    }
});

ipcMain.on("notify", (_event, msg) => {
    if (!msg || typeof msg.type !== "string") return;

    if (msg.type === "update" || msg.type === "toast") {
        toast(String(msg.title || "Update available"), String(msg.body || ""), false);
        return;
    }

    if (msg.type === "progress") {
        const pct = Math.max(0, Math.min(100, Number(msg.percent) || 0));
        if (win) win.setProgressBar(pct / 100);
        if (!startedToast) {
            startedToast = true;
            toast("Translating subtitle...", "SinSubz is translating " + msg.total + " lines. We'll tell you when it's done.", true);
        }
        if (win) win.setTitle("SinSubz - Translating " + pct + "%");
    }

    if (msg.type === "done" || msg.type === "failed") {
        startedToast = false;
        if (win) {
            win.setProgressBar(-1);
            win.setTitle("SinSubz");
            if (!win.isFocused()) win.flashFrame(true);
        }
        if (msg.type === "done") {
            toast("Translation finished \u2713", msg.count + " subtitles translated to Sinhala. Your file is ready.", false);
        } else {
            toast("Translation failed", String(msg.message || "Something went wrong. Please try again."), false);
        }
    }
});

app.setAppUserModelId("com.visal.sinsubz.desktop");

function showWindow() {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.show();
    win.focus();
}

function createTray() {
    const icon = nativeImage
        .createFromPath(path.join(__dirname, "app", "logo.png"))
        .resize({ width: 24, height: 24 });

    tray = new Tray(icon);
    tray.setToolTip("SinSubz");

    const menu = () => Menu.buildFromTemplate([
        { label: "Open SinSubz", click: showWindow },
        {
            label: "Start with Windows",
            type: "checkbox",
            checked: app.getLoginItemSettings({ args: ["--hidden"] }).openAtLogin,
            click: (item) => app.setLoginItemSettings({ openAtLogin: item.checked, args: ["--hidden"] })
        },
        { type: "separator" },
        { label: "Quit", click: () => { quitting = true; app.quit(); } }
    ]);

    tray.setContextMenu(menu());
    tray.on("click", showWindow);
    tray.on("right-click", () => tray.setContextMenu(menu()));
}

app.on("before-quit", () => {
    quitting = true;
    if (exportJob) { try { exportJob.cancel(); } catch (e) { /* ignore */ } }   // do not leave ffmpeg running
});

app.whenReady().then(() => {
    if (!gotLock) return;
    createWindow();
    createTray();
    app.on("activate", () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on("second-instance", showWindow);

app.on("window-all-closed", () => {
    if (process.platform !== "darwin") app.quit();
});
